from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/analizza_keyword', methods=['GET'])
def analizza_keyword():
    keyword = request.args.get('keyword', '')
    if not keyword:
        return jsonify({'error': 'Nessuna keyword fornita'}), 400

    # Risposta simulata
    response = {
        "keyword": keyword,
        "categoria_suggerita": "Libri da colorare per adulti",
        "titoli_simili": [
            "Simple Mandala Coloring Book",
            "Relaxing Mandala Patterns",
            "Stress Relief Coloring"
        ],
        "idee_di_contenuto": [
            "Mandala floreali",
            "Mandala con animali",
            "Mandala geometrici"
        ]
    }
    return jsonify(response)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)